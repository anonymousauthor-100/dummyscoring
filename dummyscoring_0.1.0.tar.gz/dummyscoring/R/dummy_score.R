#' Dummy Extension Scoring
#' 
#' Scores a matrix or dataframe on latent factors, using Dummy Extension Scoring (Keenan, 2023). The factors to be scored can either be provided in the form of a psych::fa output, or a matrix of loadings. Alternatively, if only a data matrix is provided, the factor analysis will be performed within the dummy_score function, with parameter passed by '...' The user can select 'core.variables' to be factored, and also 'scoring.variables' to be used in the scoring step. The 'scoring.variables' can include factored variables, variables not factored, or any combination thereof.
#'
#' @param data A matrix or dataframe containing the data to be analyzed
#' @param fa (optional) An object of class 'fa' from the 'fa' function in the 'psych' package, used to define the factors to be scored
#' @param loadings (optional) Alternatively, a matrix of factor loadings
#' @param method Which Dummy-Extension method to use. Options are 'Rubin','Bartlett','Harman', and 'Anderson.' Rubin is similar to the Thurstone method in traditional factor analysis, and Bartlett and Harman are precisely the same. 'Anderson' is short for the Anderson/Rubin method that produces uncorrelated factor scores.
#' @param parallel A logical indicating whether to use multiple cores for scoring. This will only offer speed improvement for very large datasets, and will probably be slower for most datasets.
#' @param core.variables (optional) Can be either a vector of variable names or index numbers. Defines the 'core' variables from which the factor extension is done. If 'fa' and 'loadings' and 'corr.matrix' are all null, it will use all the variables in 'data.'
#' @param scoring.variables (optional) Either a vector of variable names of index numbers. Defines the variables used in the scoring step, which can be 'core' variables or other variables, or any combination thereof. Defaults to all the variables in 'data.'
#' @param corr.matrix (optional) A correlation matrix of the 'core' variables, used in the factor extension step
#' @param ... (optional) Arguments passed to the psych::fa function if no factor loadings are provided. See psych::fa for more details.
#' @return A list with elements 'scores,' 'original.loadings,' and 'extension.loadings.' The factor scores for every observation are contained in 'scores.'
#' @export
#' @examples
#' \dontrun{big.five.scores <- dummy_score(data = bigfive, method = 'Bartlett')$scores}

dummy_score <- function(data,fa=NULL,loadings=fa$loadings,method=c('Rubin','Bartlett','Harman','Anderson'),parallel=F,
                       core.variables=NULL,scoring.variables=NULL,corr.matrix=NULL,...){
  
  method <- match.arg(method) # If no method specified, use the Rubin method
  
  # This defines a function to do an inverse matrix square root, which is used in the Anderson method
  
  invMatSqrt <- function(x,correct=F){
    if(dim(x)[1]==1) return(sign(x)*1/sqrt(abs(x)))
    e <- svd(x)
    changed <- diag(1/sqrt(e$d))
    if(correct) changed[e$d<1] <- 0 else changed[e$d<.000001] <- 0
    return(e$u%*%changed%*%t(e$u))
  }
  
  # This function replaces NA values with zeros
  
  na.zeros <- function(x) `[<-`(x,is.na(x),value=0)
  
  # This function takes in a response vector X and scores it
  
  score <- function(X,P,R,f,U.inv,method=c('Rubin','Bartlett','Harman','Anderson')){
    not.na <- !is.na(X)
    P <- P[not.na,]; R <- R[not.na,not.na]; U.inv <- U.inv[not.na,not.na]; X <- X[not.na]
    W <- switch(method,
             Rubin = U.inv%*%P%*%MASS::ginv(diag(1,f)+t(P)%*%U.inv%*%P),        # W = inv(U) x P x inv(I + t(P) x  inv(U) x P)
             Bartlett = U.inv%*%P%*%MASS::ginv(t(P)%*%U.inv%*%P),               # W = inv(U) x P x inv(t(P) x  U.inv x P)
             Harman = P%*%MASS::ginv(crossprod(P)),                             # W = P x inv(t(P) x P)
             Anderson = U.inv%*%P%*%invMatSqrt(t(P)%*%U.inv%*%R%*%U.inv%*%P))   # W = inv(U) x P x inv(t(P) x inv(U) x R x inv(U) x P)
    validity <- (diag(t(P)%*%W) / sqrt(diag(t(W)%*%R%*%W))) |> min()
    return(c(X%*%W, validity))
  }
  
  # Create numeric and factor versions of the data matrix

  X.num <- apply(data,2,as.numeric)
  X.fac <- apply(data,2,as.factor)
  
  # Depending on what has been provided as arguments, choose core and extension variables
  
  v.candidates <- list(core.variables,rownames(loadings),colnames(corr.matrix),colnames(data))
  v <- v.candidates[vapply(v.candidates,\(x)!is.null(x),T)][[1]]
  v <- v[v%in%colnames(data)]
  e <- if(is.null(scoring.variables)) colnames(data) else scoring.variables
  e <- e[e%in%colnames(data)]
  
  # Create matrix of dummy variables and center them

  X.ne <- X.fac[,e] |> fastDummies::dummy_cols(ignore_na=T,remove_selected_columns=T) |> scale(scale=F)
  
  # Calculate core-variable correlation matrix if not given, and replace NAs with zeros

  R.vv <- (if(is.null(corr.matrix)) stats::cor(X.num[,v],use='pairwise.complete.obs') else corr.matrix[v,v]) |> na.zeros()

  # If loadings not given, run a factor analysis, with arguments passed down

  if(is.null(loadings)) loadings <- psych::fa(R.vv,...)$loadings
  f <- ncol(loadings)
  
  # Calculate extension correlation matrix if not given, and replace NAs with zeros

  R.ev <- stats::cor(X.ne,X.num[,v],use='pairwise.complete.obs') |> suppressWarnings() |> na.zeros()

  # Using the Gorsuch factor extension method, find loadings and uniquenesses for dummy variables
  
  P.ef <- R.ev%*%MASS::ginv(R.vv)%*%loadings[v,]
  R.ee <- tcrossprod(P.ef) |> (`diag<-`)(1)
  U.inv <- diag(1/(1-rowSums(P.ef^2)))
  
  # Now do the row-by-row scoring, in parallel if requested
  
  if(parallel){
    future::plan(future::multisession)
    scores <- X.ne |> future.apply::future_apply(1,score,x,P.ef,R.ee,f,U.inv,method) |> matrix(ncol=f+1,byrow=T)} 
  else scores <- X.ne |> apply(1,score,P.ef,R.ee,f,U.inv,method) |> matrix(ncol=f+1,byrow=T)

  # Return the estimated scores, original loadings, and extension loadings
  
  return(list(scores=scores,original.loadings=loadings,extension.loadings=P.ef))
}
